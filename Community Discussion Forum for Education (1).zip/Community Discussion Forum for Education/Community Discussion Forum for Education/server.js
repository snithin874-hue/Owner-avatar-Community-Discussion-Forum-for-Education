const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

let users = [];
let posts = [
    {
        title: "Welcome to the Community Forum",
        category: "General",
        content: "Share your first discussion topic here.",
        author: "Admin"
    }
];

app.post("/register", (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({
            message: "Username, email, and password are required"
        });
    }

    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
        return res.status(409).json({
            message: "Email is already registered"
        });
    }

    const user = { username, email, password };
    users.push(user);

    res.json({
        message: "Registration Successful",
        user: { username, email }
    });
});

app.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            message: "Email and password are required"
        });
    }

    const user = users.find(
        u => u.email === email && u.password === password
    );

    if (user) {
        return res.json({
            message: "Login Successful",
            user: { username: user.username, email: user.email }
        });
    }

    res.status(401).json({
        message: "Invalid Email or Password"
    });
});

app.get("/posts", (req, res) => {
    res.json(posts);
});

app.post("/posts", (req, res) => {
    const { title, category, content, author } = req.body;

    if (!title || !author) {
        return res.status(400).json({
            message: "Title and author are required"
        });
    }

    const post = {
        title,
        category: category || "General",
        content: content || "",
        author
    };

    posts.push(post);

    res.json({
        message: "Post created successfully",
        post
    });
});

app.listen(5000, () => {
    console.log("Server running on http://localhost:5000");
});