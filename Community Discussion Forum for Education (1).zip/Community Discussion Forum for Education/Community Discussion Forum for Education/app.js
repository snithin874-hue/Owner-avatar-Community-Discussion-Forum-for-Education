const API = "http://localhost:5000";

async function loadPosts() {
    const response = await fetch(`${API}/posts`);
    const posts = await response.json();

    const container = document.getElementById("posts");

    container.innerHTML = posts.map(post => `
        <div class="post">
            <h3>${post.title}</h3>
            <p>${post.category}</p>
            <small>${post.author}</small>
        </div>
    `).join("");
}

async function createPost() {
    const title = document.getElementById("title").value;
    const currentUser = JSON.parse(localStorage.getItem("user") || "null");

    if (!title) {
        return;
    }

    if (!currentUser) {
        alert("Please login before posting.");
        return;
    }

    await fetch(`${API}/posts`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title,
            category: "General",
            content: "",
            author: currentUser.username
        })
    });

    document.getElementById("title").value = "";
    loadPosts();
}

async function registerUser() {
    const username = document.getElementById("regUser").value;
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;

    const response = await fetch(`${API}/register`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, email, password })
    });

    const result = await response.json();
    const messageElement = document.getElementById("registerMsg");

    if (!response.ok) {
        messageElement.innerText = result.message || "Registration failed.";
        return;
    }

    messageElement.innerText = result.message;
    document.getElementById("regUser").value = "";
    document.getElementById("regEmail").value = "";
    document.getElementById("regPassword").value = "";
}

async function login() {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    const response = await fetch(`${API}/login`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
    });

    const result = await response.json();
    const messageElement = document.getElementById("loginMsg");

    if (!response.ok) {
        messageElement.innerText = result.message || "Login failed.";
        return;
    }

    localStorage.setItem("user", JSON.stringify(result.user));
    messageElement.innerText = result.message;
    closeModal();
    loadPosts();
}

loadPosts();